

TO build .whl of this package
```
python -m pip install setuptools wheel --upgrade --user
python setup.py sdist bdist_wheel
```
